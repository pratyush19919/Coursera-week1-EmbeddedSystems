# Introduction to Embedded Systems Software and Development Environments

## Coursera MOOC - Univeristy of Colorado Boulder

### Week 1 - Application Assignment

Analyze an array of unsigned char data items and report analytics on the maximum, minimum, and median of the dataset. 

Author: Sai Pratyush Tangirala
